const {
  Interaction,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  EmbedBuilder,
  ChannelType,
} = require("discord.js");
const { QuickDB } = require("quick.db");
module.exports = {
  name: "ready",
  once: true,
  async execute(client) {
    
  },
};
