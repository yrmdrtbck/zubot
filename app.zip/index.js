const {
  Collection,
  AuditLogEvent,
  ActivityType,
  EmbedBuilder,
  Client,
  StringSelectMenuBuilder,
  GatewayIntentBits,
  MessageButton,
  Events,
  Partials,
  AttachmentBuilder,
  MessageActionRow,
  ActionRowBuilder,
  ButtonStyle,
  ButtonBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require("discord.js");
const fs = require("fs");
const path = require("path");
const moment = require("moment");
require("moment/locale/tr");
const client = new Client({
  intents: Object.values(GatewayIntentBits).filter(
    (x) => typeof x === "string"
  ),
  partials: Object.values(Partials).filter((x) => typeof x === "string"),
});
const { token } = require("./src/base/settings.json");
const { QuickDB } = require("quick.db");
const db = new QuickDB();
client.commands = new Collection();
const functions = fs
  .readdirSync("./src/functions")
  .filter((file) => file.endsWith(".js"));
const eventFiles = fs
  .readdirSync("./src/events")
  .filter((file) => file.endsWith(".js"));
const commandFolders = fs.readdirSync("./src/commands");



(async () => {
  for (let file of functions) {
    require(`./src/functions/${file}`)(client);
  }
  client.handleCommands(commandFolders, "./src/commands");
  client.handleEvents(eventFiles, "./src/events");
  client.login(token);
})();