const { prefix } = require("../base/settings.json");
const {QuickDB} = require('quick.db');
const db = new QuickDB();
module.exports = {
  name: "messageCreate",
  async execute(message, client) {
    //--------------------------PREFIX COMMAND HANDLER
    if (message.content.startsWith(prefix) && !message.author.bot) {
      const args = message.content.slice(1).split(/ +/);
      const commandName = args.shift().toLowerCase();

      const command = client.prefixCommands.get(commandName);

      if (!command) return;

      try {
        command.execute(message);
      } catch (error) {
        console.error(error);
        message.reply("There was an error executing that command!");
      }
    }
  }
};
